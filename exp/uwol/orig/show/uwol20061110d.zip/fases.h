// Estructura para las distintas pantallas,
// 10 + 6 + 20 + 1 = 37 bytes por pantalla.

typedef struct
{
	unsigned char descriptor;
	unsigned int obj[10];
	unsigned int movil[3];
	unsigned char coin[10];
} FASE;

extern FASE fases[];

// Definición de las pantallas del juego según esta documentación:
/*
B:  L:   C:
0   1    Byte descriptor de fase: TTPPPIII 
         TT : 2 bits, número de tile de fondo (0 a 3) 
         PPP: 3 bits, color de PAPER (0 a 8) 
         III: 3 bits, color de INK (0 a 8) 

1   2    Descriptor de objeto, 2 bytes: XXXXYYYYLLLLTTTD 
         XXXX: 4 bits, coordenada X en tiles de la esquina sup.izq (0 a 15) 
         YYYY: 4 bits, coordenada Y en tiles de la esquina sup.izq (0 a 15) 
         LLLL: 4 bits, longitud del objeto en tiles (0 a 15) 
         TTT: 3 bits, número de objeto (0 a 7) 
         D: 1 bit, dirección: 0 horz, 1 vert. 

         P.ej. una plataforma de 6 tiles de ancho en (2, 2) del tipo 2, sería: 
         0010001001100100 
         [ 2][ 2][ 6][2]0 

... x 10 
21   2   Descriptor de enemigo, 2 bytes: AAAABBBBYYYYRTTV 
         AAAA: 4 bits, nº tile horizontal límite izquierdo (0 a 15) 
         BBBB: 4 bits, nº tile horizontal límite derecho (0 a 15) 
         YYYY: 4 bits, nº tile vertical (0 a 15) 
         R: 1 bit, reservado (por ahora no sirve pa ná).
         TT: 2 bits, tipo de enemigo (0 a 3); 1 = franky, 2 = vampy, 3 = fanty.
         V: 1 bit, velocidad: 0 lento (de 1 en 1 pixels), 1 rápido (de 2 en 2 píxels). 
... x 3 
27   1   Descriptor de moneda, 1 byte: XXXXYYYY 
         XXXX: 4 bits, coordenada X en tiles (0 a 15) 
         YYYY: 4 bits, coordenada Y en tiles (0 a 15) 
... x 10
*/
#asm
._fases

// Tres pantallas de anjuel, 7 de Noviembre.

;.Pantalla 1
        ;TTPPPIII
   defb @00001101            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @11000110, @00000000
   defb @00110000, @00010011
   defb @00110000, @10000011
   defb @00100000, @01010101
   defb @00110000, @00010111
   defb @00110000, @10000111
   defb @11000110, @00001001
   defb @00000000, @00000000
   defb @00000000, @00000000
   defb @00000000, @00000000


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00010101, @00011010
   defb @01100011, @00011010
   defb @00000000, @00000000


        ;Monedas
        ;XXXXYYYY
   defb @00010010
   defb @00110010
   defb @10010010
   defb @10100010
   defb @01010100
   defb @01100100
   defb @00010110
   defb @00110110
   defb @10000110
   defb @10100110

;.Pantalla 2
;TTPPPIII
   defb @00000100            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @11000100, @00000000
   defb @00110101, @00000001
   defb @00010111, @10100010
   defb @00010111, @10010011
   defb @00110110, @00100101
   defb @00110110, @10000101
   defb @00110101, @10110110
   defb @00110110, @01010111
   defb @11000100, @00001001
   defb @00000000, @00000000


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00100010, @01101001
   defb @01010000, @01010111
   defb @00000000, @00000000


        ;Monedas
        ;XXXXYYYY
   defb @10010010
   defb @00100100
   defb @00110100
   defb @01000100
   defb @10000100
   defb @10110101
   defb @01010110
   defb @01100110
   defb @01110110
   defb @00011000



;.Pantalla 3
        ;TTPPPIII
   defb @01000011            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @11000010, @00000000
   defb @00011011, @00010100
   defb @00011011, @01000100
   defb @00011011, @01110100
   defb @00011011, @10100100
   defb @00011011, @01010110
   defb @00011011, @01100110
   defb @01001010, @01000111
   defb @01101010, @00111000
   defb @11000010, @00001001


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00110011, @00101001
   defb @01010000, @00100101
   defb @01010100, @01101001


        ;Monedas
        ;XXXXYYYY
   defb @00100010
   defb @00110010
   defb @01010010
   defb @01100010
   defb @10000010
   defb @10010010
   defb @00010011
   defb @01000011
   defb @01110011
   defb @10100011

// Dos pantallas de Agus, 8 de Noviembre

;.Pantalla 4
        ;TTPPPIII
   defb @10001101            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @11001100, @00000000
   defb @10101100, @00100011
   defb @00011100, @00010101   
   defb @10101100, @00000110
   defb @00011100, @10101000
   defb @11001100, @00001001
   defb @00000000, @00000000
   defb @00000000, @00000000
   defb @00000000, @00000000
   defb @00000000, @00000000


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00100101, @00001011
   defb @01010010, @00101011
   defb @10000100, @00111001


        ;Monedas
        ;XXXXYYYY
   defb @00010001
   defb @01010001
   defb @10010001
   defb @00010100
   defb @01010100
   defb @10010100
   defb @10110110
   defb @00010111
   defb @01010111
   defb @10010111


;.Pantalla 5
        ;TTPPPIII
   defb @10000100            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @11000000, @00000000
   defb @00110101, @00000001
   defb @00100101, @10110001
   defb @10010000, @00110011
   defb @00110101, @10110101
   defb @00101000, @00000101
   defb @10010000, @00000110
   defb @00010101, @00000111
   defb @00011000, @10011000
   defb @11000000, @00001001


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00100010, @00111010
   defb @01000011, @00011010
   defb @01110100, @00101000


        ;Monedas
        ;XXXXYYYY
   defb @00100001
   defb @01000001
   defb @01100001
   defb @10000001
   defb @10100001
   defb @00010100
   defb @00110100
   defb @01010100
   defb @01110100
   defb @10010100

// Dos pantallas de anjuel, 9 de Noviembre.

;.Pantalla 6 
        ;TTPPPIII 
   defb @00000111            ; Descriptor 

        ;Objetos 
        ;datos "al reves", por eso del "endian" 
        ;LLLLTTTD   XXXXYYYY 
   defb @11001010, @00000000 
   defb @01100111, @10110001 
   defb @01100111, @00010010 
   defb @00010111, @01000010 
   defb @00010111, @01100011 
   defb @00100110, @01100101 
   defb @00010111, @10000110 
   defb @00110110, @00100111 
   defb @01000110, @01111000 
   defb @11001010, @00001001 


        ;Moviles 
        ;YYYYTTTD   AAAABBBB 
   defb @00010010, @00001010 
   defb @01000100, @00100101 
   defb @00000000, @00000000 


        ;Monedas 
        ;XXXXYYYY 
   defb @01100010 
   defb @00000011 
   defb @00000100 
   defb @00000101 
   defb @00000110 
   defb @00100110 
   defb @00110110 
   defb @01000110 
   defb @00000111 
   defb @00001000 


;.Pantalla 7 
        ;TTPPPIII 
   defb @00000110            ; Descriptor 

        ;Objetos 
        ;datos "al reves", por eso del "endian" 
        ;LLLLTTTD   XXXXYYYY 
   defb @11000110, @00000000 
   defb @01110101, @00000001 
   defb @01110101, @10110001 
   defb @00011001, @01010011 
   defb @00011001, @10010100 
   defb @00011001, @01100101 
   defb @00011001, @01000110 
   defb @00011001, @00100111 
   defb @00011001, @10000111 
   defb @11000110, @00001001 


        ;Moviles 
        ;YYYYTTTD   AAAABBBB 
   defb @00010010, @00011010 
   defb @01000101, @00011000 
   defb @01110001, @00110111 


        ;Monedas 
        ;XXXXYYYY 
   defb @01000010 
   defb @01100010 
   defb @10010010 
   defb @01000011 
   defb @10010011 
   defb @00100101 
   defb @01000101 
   defb @10000101 
   defb @00100110 
   defb @10000110

// Pantalla de DadMan, 10 de Noviembre

;.Pantalla 8
        ;TTPPPIII
   defb @00001100            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @11000100, @00000000
   defb @01010100, @00000011
   defb @00110100, @10000011
   defb @01011011, @10100100
   defb @00011001, @01100101
   defb @00101010, @00110111
   defb @00111010, @00101000
   defb @00011001, @10001000
   defb @01101010, @00001001
   defb @00101010, @10101001


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00100000, @00111001
   defb @01000010, @01111001
   defb @01100101, @01001001


        ;Monedas
        ;XXXXYYYY
   defb @00000001
   defb @01000001
   defb @10000001
   defb @00100010
   defb @10100010
   defb @01100100
   defb @10010101
   defb @01100111
   defb @10000111
   defb @10110111

// Pantalla de Agus (10 de Noviembre)

;.Pantalla 9
        ;TTPPPIII
   defb @10000001            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @11001100, @00000000
   defb @00101000, @00000011
   defb @00101000, @01010011
   defb @00101000, @10100011
   defb @00011001, @01000100
   defb @00011001, @01110100
   defb @00110010, @00000110
   defb @00100010, @01010110
   defb @00110010, @10010110
   defb @11001010, @00001001


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00100010, @00000101
   defb @00100011, @01101011
   defb @01010011, @00001011


        ;Monedas
        ;XXXXYYYY
   defb @00000010
   defb @00110010
   defb @01010010
   defb @01100010
   defb @10000010
   defb @10110010
   defb @00000101
   defb @00100101
   defb @10010101
   defb @10110101

// Pantallas de Benway (10 de Noviembre)

;.Pantalla 10
        ;TTPPPIII
   defb @11000011            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @00110111, @01000001
   defb @01010111, @01100001
   defb @01100111, @10000001
   defb @01110111, @10100001
   defb @00010111, @10110001
   defb @00010111, @00100010
   defb @00110110, @00000011
   defb @00010111, @10110101
   defb @01011000, @00010111
   defb @11000110, @00001001


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00000101, @00001011
   defb @01010000, @00000101
   defb @00000000, @00000000


        ;Monedas
        ;XXXXYYYY
   defb @01010010
   defb @01110010
   defb @10010010
   defb @01110011
   defb @10010011
   defb @01110100
   defb @10010100
   defb @00000000
   defb @00000000
   defb @00000000


;.Pantalla 11
        ;TTPPPIII
   defb @10010000            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @00010101, @00100001
   defb @00110100, @01010001
   defb @01100101, @00000011
   defb @10010100, @00010101
   defb @00100101, @10110111
   defb @11000100, @00001001
   defb @00000000, @00000000
   defb @00000000, @00000000
   defb @00000000, @00000000
   defb @00000000, @00000000


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00110101, @00010110
   defb @00110101, @01101011
   defb @01100010, @00011011


        ;Monedas
        ;XXXXYYYY
   defb @01110000
   defb @01010010
   defb @01100010
   defb @01110010
   defb @00100110
   defb @00110110
   defb @10000110
   defb @10010110
   defb @00000000
   defb @00000000


;.Pantalla 12
        ;TTPPPIII
   defb @00000111            ; Descriptor

        ;Objetos
        ;datos "al reves", por eso del "endian"
        ;LLLLTTTD   XXXXYYYY
   defb @01101101, @00110010
   defb @00111101, @10000010
   defb @00011101, @01000011
   defb @00101100, @10100011
   defb @00101100, @00000101
   defb @01011100, @01000101
   defb @00101101, @10000110
   defb @00101100, @10010111
   defb @11001100, @00001001
   defb @00000000, @00000000


        ;Moviles
        ;YYYYTTTD   AAAABBBB
   defb @00000101, @00001011
   defb @00100001, @01000111
   defb @10000011, @00011011


        ;Monedas
        ;XXXXYYYY
   defb @01000100
   defb @01010100
   defb @01100100
   defb @01110100
   defb @01010111
   defb @01100111
   defb @00000000
   defb @00000000
   defb @00000000
   defb @00000000

#endasm
