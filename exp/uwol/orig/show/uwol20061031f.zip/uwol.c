#include <spritepack.h>

/* Extern pointers for the graphic definitions: */

#include "sprites.h"
#include "tiles.h"

/* Allocate space for the stack */

#pragma output STACKPTR=61440

/* Addresses */

#define AD_FREE		55000

/* Game constants */

#define WYZ_INTERRUPT 24520
#define WYZ_LOAD 24563
#define WYZ_INTERR 25266
#define WYZ_PLAY_SOUND 24548

#define PUCRUNCH		33163

char play = 0;

#asm 
defw 0                        /* two free bytes before start of a hook */ 
#endasm 
void musicISR(void) 
{ 
	if (play)
	{
	#asm 
			push af
			push bc
			push de
			push hl
			push ix

			call WYZ_INTERRUPT 

			pop ix
			pop hl
			pop de
			pop bc
			pop af
	#endasm 
	}
} 

/* Import sp_ClipStruct */

extern struct sp_Rect *sp_ClipStruct;

#asm
	LIB SPCClipStruct
._sp_ClipStruct         
	defw SPCClipStruct
#endasm

struct sp_Rect spritesClipValues;
struct sp_Rect *spritesClip;

/* Manage keys and joystick at the same time: */

struct sp_UDK keys;

/* Create memory allocator for sprite routines */

void *my_malloc(uint bytes)
{
   return sp_BlockAlloc(0);
}

void *u_malloc = my_malloc;
void *u_free = sp_FreeBlock;

/* Strings printed during the game */

struct sp_PSS ps;         /* a print string struct used by sp_PrintString */

/* Data types */

typedef struct
{
	int x, y;
	int vx, vy;
	char g, ax, rx;
	uchar salto, cont_salto;
	uchar *current_frame, *next_frame;
	uchar saltando;
	uchar frame, subframe, facing;
	uchar estado;
	uchar ct_estado;
} INERCIA;

#define EST_NORMAL 0
#define EST_NUDE 1
#define EST_PARP 2
#define EST_MUR 4

INERCIA player;

char pantalla;

typedef struct
{
	uchar descriptor;
	unsigned int obj[10];
	unsigned int movil[5];
	unsigned char coin[10];
} FASE;

extern FASE fases[];

typedef struct 
{
	uchar x, y;
	uchar vx;
	uchar t1, t2;
	uchar *current_frame, *next_frame; 
	uchar tipo;
	struct sp_Rect clip;
} MOVILES;

MOVILES moviles[5];
struct sp_SS *sp_moviles [5];

#asm
._fases
         ;TTPPPIII
	defb @10000111				; Descriptor

		 ;datos "al reves", por eso del "endian"
         ;LLLLTTTD   XXXXYYYY   
	defb @11001110, @00000000 	; Objetos
	defb @00111110, @00010011 
	defb @01011110, @01100100 
	defb @00101110, @00110110 
	defb @00011110, @01011000
	defb @11001110, @00001001 
	defb @00000000, @00000000
	defb @00000000, @00000000
	defb @00000000, @00000000
	defb @00000000, @00000000

		 ;YYYYTTTD   AAAABBBB
	defb @00100010, @00010011	; Moviles
	defb @00110101, @01101010
	defb @00000000, @00000000
	defb @00000000, @00000000
	defb @00000000, @00000000

         ;XXXXYYYY
	defb @00010010				; Monedas
	defb @00110010
	defb @00110101
	defb @10100011
	defb @10000111
	defb @10010111
	defb @10100111
	defb @00000000
	defb @00000000
	defb @00000000
#endasm

// Almacena las monedas del nivel actual
uchar monedas[10];
uchar num_monedas;

// Para ahorrar IFs...
uchar *enem_frames [] = 
{	
	franki_1a,		franki_1a,
	vampi_1a,		vampi_1a,
	fanti_l_1a,		fanti_r_1a
};

/* WYZ music & sound calls */

extern char asm_number[1];
#asm
	._asm_number defb 0
#endasm

uchar rand ()
{
	uchar res;
#asm
	ld a,r
	ld (_asm_number), a
#endasm

	res = asm_number [0];
	return res;
}

void wyz_play_sound (char fx_number)
{
	asm_number[0] = fx_number;
	#asm
		ld a, (_asm_number)
		call WYZ_PLAY_SOUND
	#endasm
}

void wyz_play_song (char song_number)
{
	play = 0;
	asm_number[0] = song_number;
	#asm
		ld a, (_asm_number)
		call WYZ_LOAD
	#endasm
	play = 1;
}

/* Auxiliary functions */

unsigned char attr (char x, char y)
{	
	char *res = (char *) (22528 + x + (y << 5));
	return (*res);
}

/* Game functions */

unsigned char move ()
{
	uchar xx, yy;
	uchar x, y;
	uchar i;

	i = sp_JoyKeyboard (&keys); // Leemos del teclado

	/* Primera prueba del motor de movimiento de inercia para z88dk/splib2
	   Vamos a ver si esto no explota t�*/

	/* Por partes. Primero el movimiento vertical. La ecuaci� de movimien-
	   to viene a ser, en cada ciclo:

	   1.- vy = vy + g
	   2.- y = y + vy

	   O sea la velocidad afectada por la gravedad. 
	   Para no colarnos con los nmeros, ponemos limitadores:
	*/

	if (player.vy < 1024/*256*/)
		player.vy += player.g;
	else
		player.vy = 1024/*256*/;

	player.y += player.vy;

	/* El problema es que no es tan f�il... Hay que ver si no nos chocamos.
	   Si esto pasa, hay que "recular" hasta el borde del obst�ulo.

	   Por eso miramos el signo de vy, para que los c�culos sean m� sencillos.
	   De paso vamos a precalcular un par de cosas para que esto vaya m� r�ido.
	*/

	x = player.x >> 6;		// dividimos entre 64 para pixels, y luego entre 8 para tiles.
	y = player.y >> 6;
	xx = x >> 3;
	yy = y >> 3;

	if (player.vy < 0)		// estamos ascendiendo
	{
		if (attr (xx, yy) > 63 || attr (xx + 1, yy) > 63 || ((x & 7) != 0 && attr (xx + 2, yy) > 63))
		{
			// paramos y ajustamos:
			player.vy = 0;
			player.y = (yy + 1) << 9;
		}
	}
	else if (player.vy > 0)	// estamos descendiendo
	{
		if (attr (xx, yy + 2) > 63 || attr (xx + 1, yy + 2) > 63 || ((x & 7) != 0 && attr (xx + 2, yy + 2) > 63))
		{
			// paramos y ajustamos:
			player.vy = 0;
			player.y = yy << 9;
		}
	}

	/* Salto: El salto se reduce a dar un valor negativo a vy. Esta es la forma m�
	   sencilla. Sin embargo, para m� control, usamos el tipo de salto "mario bros".
	   Para ello, en cada pulsaci� dejaremos decrementar vy hasta un m�imo, y de-
	   tectando que no se vuelva a pulsar cuando estemos en el aire. Juego de banderas ;)
	*/

	if ( (i & sp_UP) == 0 && player.vy == 0 && player.saltando == 0 && (attr (xx, yy + 2) > 63 || attr (xx + 1, yy + 2) > 63 || ((x & 7) != 0 && attr (xx + 2, yy + 2) > 63)))
	{
		player.saltando = 1;
		player.cont_salto = 0;

		// Para que el inicio del salto sea m� potente: (a veces conviene):
		//player.vy -= (player.salto << 1);
	}

	if ( (i & sp_UP) == 0 && player.saltando )
	{
		player.vy -= (player.salto + 32/*16*/ - (player.cont_salto>>1));
		if (player.vy < -256/*128*/) player.vy = -256/*128*/;

		player.cont_salto ++;
		if (player.cont_salto == 12)
			player.saltando = 0;
	}

	if ( (i & sp_UP) != 0 )
		player.saltando = 0;
	
	// ----------------------------------------------------------- ok con el movimiento vertical.

	/* Movimiento horizontal:

	   Mientras se pulse una tecla de direcci�, 
	   
	   x = x + vx
	   vx = vx + ax

	   Si no se pulsa nada:

	   x = x + vx
	   vx = vx - rx
	*/

	if ( ! ((i & sp_LEFT) == 0 || (i & sp_RIGHT) == 0))
		if (player.vx > 0)
		{
			player.vx -= player.rx;
			if (player.vx < 0)
				player.vx = 0;
		}
		else if (player.vx < 0)
		{
			player.vx += player.rx;
			if (player.vx > 0)
				player.vx = 0;
		}

	if ((i & sp_LEFT) == 0)
		if (player.vx > -192)
		{
			player.facing = 0;
			player.vx -= player.ax;
		}

	if ((i & sp_RIGHT) == 0)
		if (player.vx < 192)
		{
			player.vx += player.ax;
			player.facing = 1;
		}

	player.x = player.x + player.vx;

	/* Ahora, como antes, vemos si nos chocamos con algo, y en ese caso
	   paramos y reculamos */

	y = player.y >> 6;
	x = player.x >> 6;
	yy = y >> 3;
	xx = x >> 3;

	if (player.vx < 0)
	{
		if (attr (xx, yy) > 63 || attr (xx, yy + 1) > 63 || ((y & 7) != 0 && attr (xx, yy + 2) > 63))
		{
			// paramos y ajustamos:
			player.vx = 0;
			player.x = (xx + 1) << 9;
		}
	}
	else
	{
		if (attr (xx + 2, yy) > 63 || attr (xx + 2, yy + 1) > 63 || ((y & 7) != 0 && attr (xx + 2, yy + 2) > 63))
		{
			// paramos y ajustamos:
			player.vx = 0;
			player.x = xx << 9;
		}
	}

	// Calculamos el frame que hay que poner:

	if (player.vy != 0)
	{
		if (player.facing == 0)
			player.next_frame = uwol_l_3a;
		else
			player.next_frame = uwol_r_3a;
	}
	else
	{
		if (player.vx == 0)
		{
			if (player.facing == 0)
				player.next_frame = uwol_l_2a;
			else
				player.next_frame = uwol_r_2a;
		}
		else
		{
			player.subframe ++;
			if (player.subframe == 4)
			{
				player.subframe = 0;
				player.frame = (player.frame + 1) & 3;
			}
			if (player.facing == 0)
			{
				if (player.frame == 1 || player.frame == 2)
					player.next_frame = uwol_l_2a;
				else if (player.frame == 0)
					player.next_frame = uwol_l_1a;
				else if (player.frame == 3)
					player.next_frame = uwol_l_3a;
			}
			else
			{
				if (player.frame == 1 || player.frame == 2)
					player.next_frame = uwol_r_2a;
				else if (player.frame == 0)
					player.next_frame = uwol_r_1a;
				else if (player.frame == 3)
					player.next_frame = uwol_r_3a;
			}
		}	
	}
	
	if (player.x <= 1088)
		player.x = 14270;
	
	if (player.x >= 14272)
		player.x = 1090;
}

void death_sequence ()
{
	if (player.vy < 1024/*256*/)
		player.vy += player.g;
	else
		player.vy = 1024/*256*/;

	player.y += player.vy;
	
	// Esto acaba cuando el jugador sale de la pantalla:
	
	if (player.y > 11264)
	{
		player.estado = EST_PARP;
		player.x = 32 << 6;
		player.y = 144 << 6;
		player.vx = player.vy = 0;
		player.ct_estado = 32;						// Tiempo de inmunidad.
	}
}

/* This function is called to tint an already created sprite: */

uchar whatColour;
void tintSprite (struct sp_CS *cs)
{
	cs->colour = whatColour;
}

// This sets the tileset
/*
void set_tileset ()
{
	uchar i; char *pointer = game_tiles;

	for (i = 32; i < 136; i++)
	{
		sp_TileArray (i, pointer);
		pointer+=8;
	}
}
*/

void draw_tile (char x, char y, char c, char tile)
{
	sp_PrintAtInv (y, x, c, tile);
	if (x<27) sp_PrintAtInv (y, 1 + x, c, tile + 1);
	if (y<21) sp_PrintAtInv (1 + y, x, c, tile + 2);
	if (x<27 && y<21) sp_PrintAtInv (1 + y, 1 + x, c, tile + 3);
}

void draw_lives (char lives)
{
	sp_PrintAtInv (1, 6, 71, 99);
	sp_PrintAtInv (1, 7, 69, 89 + (lives / 10));
	sp_PrintAtInv (1, 8, 69, 89 + (lives % 10));
}

void draw_score (char score)
{
	sp_PrintAtInv (1, 24, 71, 99);
	sp_PrintAtInv (1, 25, 69, 89 + (score / 100));
	sp_PrintAtInv (1, 26, 69, 89 + (score % 100) / 10);
	sp_PrintAtInv (1, 27, 69, 89 + (score % 10));
}

void draw_time (char time)
{
	sp_PrintAtInv (1, 12, 68, 100);
	sp_PrintAtInv (1, 13, 68, 101);
	sp_PrintAtInv (1, 14, 68, 102);
	sp_PrintAtInv (1, 15, 68, 103);
	sp_PrintAtInv (1, 16, 71, 99);
	sp_PrintAtInv (1, 17, 69, 89 + (time / 100));
	sp_PrintAtInv (1, 18, 69, 89 + (time % 100) / 10);
	sp_PrintAtInv (1, 19, 69, 89 + (time % 10));
}

void draw_level (char level)
{
	sp_PrintAtInv (23, 4, 68, 104);
	sp_PrintAtInv (23, 5, 68, 103);
	sp_PrintAtInv (23, 6, 68, 105);
	sp_PrintAtInv (23, 7, 68, 103);
	sp_PrintAtInv (23, 8, 68, 104);	
	sp_PrintAtInv (23, 9, 71, 99);
	sp_PrintAtInv (23, 10, 69, 89 + (level /100));
	sp_PrintAtInv (23, 11, 69, 89 + (level % 10));
}

// Atributo de cada tile
uchar attr_tiles[8] = {70, 66, 67, 68, 66, 71, 65, 69};

void draw_objetos (char n_pant)
{
	char x, y, i, j, l, n;
	// Objetos 
	for (i = 0; i < 10; i ++)
	{
		if (fases[n_pant].obj[i] != 0)
		{
			x = (unsigned char) (fases[n_pant].obj[i] >> 12) & 15;
			y = (unsigned char) (fases[n_pant].obj[i] >> 8) & 15;
			l = (unsigned char) (fases[n_pant].obj[i] >> 4) & 15;
			n = (unsigned char) (fases[n_pant].obj[i] >> 1) & 7;

			if ( (fases[n_pant].obj[i] & 1) == 0 )
			{
				// plataforma horizontal
				for (j = x; j < x + l; j ++)
					draw_tile (5 + (j<<1), 3 + (y<<1), fases[n_pant].descriptor & 63, 17 + (fases[n_pant].descriptor >> 4));
				for (j = x; j < x + l; j ++)
					draw_tile (4 + (j<<1), 2 + (y<<1), attr_tiles[n], 33 + (n<<2));
			}
			else
			{
				// plataforma vertical
				for (j = y; j < y + l; j ++)
					draw_tile (5 + (x<<1), 3 + (j<<1), fases[n_pant].descriptor & 63, 17 + (fases[n_pant].descriptor >> 4));
				for (j = y; j < y + l; j ++)
					draw_tile (4 + (x<<1), 2 + (j<<1), attr_tiles[n], 33 + (n<<2));
			}
		}
	}
}

void draw_screen (char n_pant)
{
	/* Esta funci� lee del array de pantallas y pinta la pantalla que
	   se le pasa en el argumento.
	*/
	
	char x,y,i,j;
	char l,n,v,t1,t2;

	// Primero el fondo
	for (y = 0; y < 10; y++)
		for (x = 0; x < 12; x++)
		{
			draw_tile (4 + (x<<1), 2 + (y<<1), fases[n_pant].descriptor & 63, 1 + (fases[n_pant].descriptor >> 4));
		}

	draw_objetos (n_pant);
		
	// Monedas:
	num_monedas = 0;
	for ( i = 0; i < 10; i ++)
	{
		// Primero copiamos los valores en nuestra estructura
		monedas [i] = fases [n_pant].coin [i];
		
		if (monedas [i] != 0)
		{
			// Y ahora dibujamos
			x = (unsigned char) (fases [n_pant].coin [i] >> 4);
			y = (unsigned char) (fases [n_pant].coin [i] & 15);
		
			draw_tile (4 + (x<<1), 2 + (y<<1), fases[n_pant].descriptor & 63, 65 + (fases[n_pant].descriptor >> 4));
			
			num_monedas ++;
		}
	}	
	
	// Cargamos ahora los objetos móviles
	for (i = 0; i < 5; i ++)
	{
		v = (unsigned char) (fases [n_pant].movil [i] & 1);
		n = (unsigned char) (fases [n_pant].movil [i] >> 1) & 7;
		y = (unsigned char) (fases [n_pant].movil [i] >> 4) & 15;
		t1 = (unsigned char) (fases [n_pant].movil [i] >> 12) & 15;
		t2 = (unsigned char) (fases [n_pant].movil [i] >> 8) & 15;
		
		moviles [i].x = moviles [i].t1 = 32 + (t1 << 4);
		moviles [i].t2 = 32 + (t2 << 4);
		moviles [i].y = 16 + (y << 4);
		moviles [i].vx = v + 1;
		moviles [i].tipo = n;
		
		if ( n > 0 )
			moviles [i].next_frame = enem_frames [ (n - 1) << 1 ];
	}

	sp_Invalidate(spritesClip, spritesClip);
}

void move_moviles ()
{
	// Esto mueve los cinco móviles (en caso de estar definidos, o sea, con tipo != 0
	
	uchar i;
	
	for (i = 0; i < 5; i ++)
		if ( moviles [i].tipo != 0)
		{
			moviles [i].x += moviles [i].vx;
			if ( moviles [i].x <= moviles [i].t1 || moviles [i].x >= moviles [i].t2)
				moviles [i].vx =- moviles [i].vx;
		}
}

/* Uncrunch image routine */

void uncrunch (int address)
{
	unsigned char *origin;
	unsigned char *destiny;
	unsigned char msb, lsb;

	origin = (unsigned char *) PUCRUNCH;
	destiny = (unsigned char *) PUCRUNCH + 2;

	msb = address >> 8;
	lsb = address & 255;
	
	*origin = lsb;
	origin ++;
	*origin = msb;

	*destiny = 0;
	destiny ++;
	*destiny = 64;

	// Antes de llamar a pucrunch, tintamos la pantalla de negro
	// para que no se vea tan feo:

	origin = (unsigned char *) 22528;
	while (origin < 23296)
	{
		*origin = 0;
		origin ++;
	}

	#asm
		call PUCRUNCH + 4
	#endasm
}

/* Main */

void main (void)
{
	unsigned char j, x, y, xx, yy, xt, yt;
	char i;
	char idx;
	struct sp_SS *sp_prueba;
	char flag1, flag2;
	char *timer;
	unsigned char *wyz_music_flag;
	unsigned char *allpurposepuntero;
	uchar maincounter = 0;
	uchar n_pant = 0;
	uchar lives, score, time;
	uchar playing = 1;
	uchar xcami, ycami;

	// Ugly pseudorandom seed using the FRAMES sys var
	
	timer = 23672;
	// srand (*timer);

	/* Substitute BASICs ISR for this thingo: */
	#asm
		di
	#endasm
	
	sp_InitIM2(0xf1f1);				// Does nothing :)
	sp_CreateGenericISR(0xf1f1); 
	sp_RegisterHook(255, musicISR);  // Registramos el hook - Gracias Utopian!
	
	#asm 
		ei 
	#endasm 

	/* Initialization stuff */
	
	sp_Initialize (7, 0);
	sp_Border (BLACK);
	sp_AddMemory(0, 100, 14, AD_FREE);		// Allocate for 100 blocks of memory
	ps.flags  = sp_PSS_INVALIDATE;
    ps.bounds = sp_ClipStruct;

	keys.up    = sp_LookupKey('q');
	keys.down  = sp_LookupKey('a');
	keys.left  = sp_LookupKey('o');
	keys.right = sp_LookupKey('p');
	keys.fire  = sp_LookupKey(' ');

	/* dummy tiles */

	allpurposepuntero = game_tiles;
	for (i = 0; i < 127; i++)
	{
		sp_TileArray (i, allpurposepuntero);
		allpurposepuntero += 8;
	}

	/* Clip structure -- define it as small as possible! */

	spritesClipValues.row_coord = 2;
	spritesClipValues.col_coord = 4;
	spritesClipValues.height = 20;
	spritesClipValues.width = 24;
	spritesClip = &spritesClipValues;

	/* Create sprites */

	sp_prueba = sp_CreateSpr (sp_MASK_SPRITE, 3, uwol_r_2a, 1, TRANSPARENT);
	sp_AddColSpr (sp_prueba, uwol_r_2b, TRANSPARENT);
	sp_AddColSpr (sp_prueba, uwol_r_2c, TRANSPARENT);
	player.current_frame = player.next_frame = uwol_r_2a;
	
	for (i = 0; i < 5; i++)
	{
		// Como los móviles siempre van a estar alineados verticalmente a caracter, no es necesario
		// definirlos de 3 filas. Con 2 basta. Así ahorramos memoria y velocidad.
		sp_moviles [i] = sp_CreateSpr(sp_MASK_SPRITE, 2, franki_1a, 2, TRANSPARENT);
		sp_AddColSpr (sp_moviles [i], franki_1b, TRANSPARENT);
		sp_AddColSpr (sp_moviles [i], franki_1c, TRANSPARENT);

		sp_MoveSprAbs (sp_moviles [i], &moviles [i].clip, 0, moviles [i].y >> 3, moviles [i].x >> 3, moviles [i].x & 7, moviles [i].y & 7);
		moviles [i].current_frame = moviles [i].next_frame = franki_1a;
	}

	player.x = 32 << 6;
	player.y = 144 << 6;
	player.vy = 0;
	player.g = 32; //8;
	player.vx = 0;
	player.ax = 16; //8;
	player.rx = 16; //8;
	player.salto = 48;
	player.cont_salto = 1;
	player.saltando = 0;
	player.frame = 0;
	player.subframe = 0;
	player.facing = 1;
	player.estado = EST_NORMAL;
	
	lives = 3;
	score = 0;
	n_pant = 0;
	time = 99;

	/* Dummy background */

	draw_screen (n_pant);
	draw_lives (lives);
	draw_time (time);
	draw_level (n_pant);
	draw_score (score);
	
	draw_tile (4, 0, 71, 106);
	draw_tile (22, 0, 70, 110);

	while (playing)
	{
		maincounter ++;		// Como es un uchar, irá siempre de 0 a 255, con ciclos potencias de 2.
		
		sp_UpdateNow();
		
		/* Move sprites */

		if ( !(player.estado & EST_MUR) )
			move ();
		else
			death_sequence ();
		
		move_moviles ();

		x = player.x >> 6;
		y = player.y >> 6;

		/* Collisions & game mechanics: */
		
		if ( player.estado & EST_PARP )			// Duración de la inmunidad:
		{
			player.ct_estado --;
			if (player.ct_estado == 0)
				player.estado = player.estado & (~EST_PARP);
		}
		
		if ( player.estado <= 1 )		// Colisión con enemigos:
			for ( i = 0; i < 5; i ++ )
				if ( moviles [i].tipo != 0)
				{
					if (y >= moviles [i].y - 14 && y <= moviles [i].y + 14 && x >= moviles [i].x - 14 && x <= moviles [i].x + 14)
					{
						if ( !(player.estado & EST_NUDE) )
						{
							sp_Border (2);
							player.estado |= EST_NUDE;
							player.estado |= EST_PARP;					// Parpadeamos inmunes.
							player.ct_estado = 32;						// Tiempo de inmunidad.
							
							do
							{
								xcami = 32 + ((rand () % 12) << 4);
								ycami = 16 + (1 + (rand () % 8) << 4);
							} while ( attr ( xcami >> 3, ycami >> 3) > 63 );
							
							draw_tile (xcami >> 3, ycami >> 3, 16 + (fases[n_pant].descriptor & 63), 85);
						}
						else
						{
							sp_Border (0);
							player.vy = - 6 * (player.salto);
							lives --;

							if (lives == 0)
								playing = 0;
							else
								draw_lives (lives);

							player.estado |= EST_MUR;
							draw_tile (xcami >> 3, ycami >> 3, fases[n_pant].descriptor & 63, 1 + (fases[n_pant].descriptor >> 4));
						}

						moviles [i].vx =- moviles [i].vx;			// El enemigo se da media vuelta.
					}
				}

		if ( player.estado & EST_NUDE )		// Colisión con la camiseta
			if (y >= ycami - 14 && y <= ycami + 15 && x >= xcami - 15 && x <= xcami + 15)
			{
				score += 5;
				draw_score (score);
				
				sp_Border (0);
				player.estado &= (~EST_NUDE);
				player.estado |= EST_PARP;
				player.ct_estado = 32;
				
				draw_tile (xcami >> 3, ycami >> 3, fases[n_pant].descriptor & 63, 1 + (fases[n_pant].descriptor >> 4));
				draw_objetos (n_pant);
			}
				
		if ( num_monedas > 0) // Vemos si colisionamos con alguna moneda.
		{
			for (i = 0; i < 10; i ++)
				if (monedas [i] != 0)
				{
					xt = (unsigned char) (monedas [i] >> 4) << 1;
					yt = (unsigned char) (monedas [i] & 15) << 1;
					
					xx = 32 + (xt << 3);
					yy = 16 + (yt << 3);

					if (y >= yy - 10 && y <= yy + 10 && x >= xx - 10 && x <= xx + 10)
					{
						monedas [i] = 0;
						num_monedas --;
						score ++;
						draw_score (score);
						draw_tile (4 + xt, 2 + yt, fases[n_pant].descriptor & 63, 1 + (fases[n_pant].descriptor >> 4));
					}
				}
		}
		else
		{
			// Lógica de pasar de fase...
		}

		/* Render */
		
		if ( !(player.estado & EST_PARP) || !(maincounter & 1) )
			sp_MoveSprAbs (sp_prueba, spritesClip, player.next_frame - player.current_frame, y >> 3, x >> 3, x & 7, y & 7);
		else
			sp_MoveSprAbs (sp_prueba, spritesClip, player.next_frame - player.current_frame, 0,0,0,0);	// Parpadeo :o)
		
		player.current_frame = player.next_frame;
		
		for ( i = 0; i < 5; i ++ )
			if ( moviles [i].tipo != 0)
			{
				sp_MoveSprAbs (sp_moviles [i], spritesClip, moviles [i].next_frame - moviles [i].current_frame, moviles [i].y >> 3, moviles [i].x >> 3, moviles [i].x & 7, moviles [i].y & 7);
				moviles [i].current_frame = moviles [i].next_frame;
			}
	}
}
