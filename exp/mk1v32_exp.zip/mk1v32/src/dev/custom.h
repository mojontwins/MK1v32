// MTE MK1 v3.2
// Copyleft 2011, 2026 by The Mojon Twins

void before_vsync (void) {
}

#ifdef PLAYER_CUSTOM_VENG
	void player_custom_veng (void) {
		// Modify vy as needed
	}
#endif

#ifdef PLAYER_CUSTOM_HENG
	void player_custom_heng (void) {
		// Modify vx as needed
	}
#endif

#ifdef PLAYER_CUSTOM_FRAME
	unsigned char player_custom_frame (void) {
		// Return a frame NUMBER (0-7)
	}
#endif

#ifdef PLAYER_CUSTOM_MOVE
	void player_custom_move (void) {
		// Replaces the whole player engine (move () after the keys are read and
		// custom_pre_move ()). Move player.x, player.y (1/64 px), set vx, vy,
		// gpx, gpy (pixels), player.possee, player.facing, and the sprite:
		// player.next_frame (sprite_cells [n]). Hurting: player.life,
		// player.estado = EST_PARP + player.ct_estado for PLAYER_FLICKERS.
	}
#endif

#ifdef PLAYER_CUSTOM_BG_HIT
	unsigned char custom_bg_hit (void) {
		// check hit_v, hit_h and modify player.x / player.y as you need
		// Return 1 if hit registered
	}
#endif

#ifdef ENABLE_CUSTOM_ENEMS

	void extra_enems_init (void) {
		// Runs for each enemy when entering a new screen. You should check _en_t
		// Current malote is malotes [enoffsmasi], iterator is enit
	}

	void extra_enems_move (void) {
		// Check _en_t and update your custom enemies. When you are finished. 
		// Current enemy vars are copied to temporary _en_x, _en_y, etc
		// write a proper frame pointer to en_an_next_frame
	}

	void extra_enems_checks (void) {
		// This is called at the end of the enems update loop, after collisions
		// Current enemy vars are copied to temporary _en_x, _en_y, etc
		// with player or bullets have been tested.
	}

	void extra_enems_killed (void) {
		// This is called after enem number enit is killed.
		// _en_t has been already "marked as dead" (OR 128)
		// Current enemy vars are copied to temporary _en_x, _en_y, etc
	}

	unsigned char this_enemy_kills (void) {
		// return 0 for enemies which shouldn't collide.
		// Collide means they will kill the player or get squashed.

		return 1;
	}

#endif

#ifdef ENABLE_CUSTOM_SPRITES
	void custom_sprites_create (void) {
		// Called once at boot, after the engine has created its sprites.
		// ZX: sp_CreateSpr your sprites (raise NUMBLOCKS in config.h).
		// CPC: set up sp_sw [SP_CUSTOM_BASE + n] (define MAX_CUSTOM_SW_SPRITES).
	}

	void custom_sprites_render (void) {
		// Called every frame at the end of render_all_sprites ().
	}

	void custom_sprites_hide (void) {
		// Called from saca_a_todo_el_mundo_de_aqui (): move them off screen.
	}
#endif

#ifdef ENABLE_CUSTOM_GAME_START
	void custom_game_start (void) {
		// A game starts: player, hotspots, enemies and n_pant are initialised,
		// the first screen hasn't been drawn yet.
	}
#endif

#ifdef ENABLE_CUSTOM_SCREEN_ENTER
	void custom_screen_enter (void) {
		// A screen has been drawn and its enemies set up (after ENTERING scripts).
		// on_pant is the previous screen (0xff on the first one of a game).
	}
#endif

#ifdef ENABLE_CUSTOM_LEVELS
	void custom_level_setup (void) {
		// Before every game and every level, before the player, hotspots,
		// bolts and enemies are initialized: load your level here (map,
		// enemies, hotspots, bolts, behaviours...). SCR_INICIO, PLAYER_INI_X
		// and PLAYER_INI_Y can be variables you set here.
	}

	unsigned char custom_level_won (void) {
		// The level is won. Return 1 to play the next one (no title, no
		// ending: custom_level_setup () is called again), 0 to end the game.
		return 0;
	}
#endif

#ifdef ENABLE_CUSTOM_PRE_MOVE
	void custom_pre_move (void) {
		// Every frame, at the start of move (): keys have just been read (pad0,
		// pad_this_frame), enemies and moving platforms are done (player.gotten,
		// ptgmx, ptgmy), the player hasn't moved. Whatever you write to
		// player.vy / ptgmx / ptgmy goes through the engine's gravity (added
		// after this), jump and collisions.
	}
#endif

#ifdef CUSTOM_RENDERER
	void custom_renderer (void) {
		// Called for every tile of a new screen, before it is drawn: the tile
		// is in _t, rdi is its index (0-149; the one above is rdi - 15), rdx,
		// rdy its viewport char coordinates. Change _t to draw something else
		// (its behaviour goes with it, into map_attr / map_buff).
		// RLE_MAP: called once the screen is decoded into map_buff (after
		// MAPPED_TILESETS): map_buff [] before rdi is final.
		// Packed maps (the default): called as the screen is decoded, in
		// order (map_buff [] before rdi is final, after it is the old screen).
		// Keep _gpit, _gp_gen, _rdt1, _rdt2.
	}
#endif

#ifdef CUSTOM_CLEAR_TILE
	void custom_clear_tile (void) {
		// An opened lock becomes tile _t, behaviour _n (default: 0, comportamiento_tiles [0])
		_t = 0; _n = comportamiento_tiles [0];
	}
#endif

#ifdef ENABLE_CUSTOM_HOTSPOTS
	unsigned char custom_hotspots() {
		// hotspot type is hotspot_t.
		// set rdi to prevent clearing the hotspot.
	}
#endif
