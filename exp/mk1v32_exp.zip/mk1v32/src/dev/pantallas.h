// MTE MK1 v3.2
// Copyleft 2011, 2026 by The Mojon Twins

// Customise title / game over / ending here

#ifdef CUSTOM_SCREENS
	// Your own title_screen (), game_over (), game_ending () (and screens)
	#include "custom_screens.h"
#else

extern unsigned char s_title [];
extern unsigned char s_marco [];
extern unsigned char s_ending [];

#ifdef CPC_DIRTY
	// CPC_DIRTY screens: zx0 of a mkts_om superbuffer (cd_unpack_screen)
	#asm
		._s_title
			BINARY "cpc/titlec.bin"
		._s_marco
		#ifndef DIRECT_TO_PLAY
			BINARY "cpc/marcoc.bin"
		#endif
		._s_ending
			BINARY "cpc/endingc.bin"
	#endasm
#else
#asm
	._s_title
		BINARY "titlec.bin"
	._s_marco

	#ifndef DIRECT_TO_PLAY
			BINARY "marcoc.bin"
	#endif
			
	._s_ending
		BINARY "endingc.bin"
#endasm
#endif

void title_screen (void) {
	#if defined CPC && defined AUTO_SPLIT
		#ifdef ALWAYS_SPLIT
			#asm
					ld  hl, pal_general
					ld  (inject_pal + 1), hl
			#endasm 
		#else
			do_split = 0;
			#asm
					call pal_general
			#endasm
		#endif
	#endif

	#ifndef CPC
		#asm 
			call SPUpdateNow
		#endasm
	#endif

	blackout ();
	#asm
			ld  hl, _s_title
			call _unpack_screen
	#endasm
	
	#ifndef CHR_MAPPED_TILES 	// the charset may have no font
	draw_text (12, 12, 
		#ifndef CPC 
			4,
		#endif
	"MK1 V3.2");
	#endif

	#ifdef CPC
		cpc_UpdateNow (0);
		AY_PLAY_MUSIC (0);
	#else 
		#asm 
				call SPUpdateNow
				call musicstart
		#endasm
	#endif

	select_controls ();
}

void game_ending (void) {
	#if defined CPC && defined AUTO_SPLIT
		#ifdef ALWAYS_SPLIT
			#asm
					ld  hl, pal_general
					ld  (inject_pal + 1), hl
			#endasm 
		#else
			#asm
					call pal_general
			#endasm
		#endif
	#endif

	#ifdef SPECCY 
		#asm 
			call SPUpdateNow
		#endasm
	#endif

	blackout ();
	#asm
			ld  hl, _s_ending
			call _unpack_screen
	#endasm

	#ifdef CPC
		cpc_ShowTileMap (1);
		AY_PLAY_MUSIC (0);
	#else
		#asm 
				call SPUpdateNow
		#endasm
		for (gpit = 0; gpit < 4; gpit ++) {
			peta_el_beeper (7);
			peta_el_beeper (2);
		}
		peta_el_beeper (9);
	#endif
	
	no_break ();
	espera_activa (5000);

	#ifdef CPC
		AY_STOP_SOUND ();
	#endif
}

#if !defined GAME_OVER_TEXT && !defined CHR_MAPPED_TILES
	#define GAME_OVER_TEXT "GAME OVER!"
#endif

void game_over (void) {
	#ifdef CPC 
		AY_STOP_SOUND ();
	#endif 

	#asm
			ld  a, 10
			ld  (__x), a
			ld  a, 11
			ld  (__y), a
			ld  a, 21
			ld  (__x2), a
			ld  a, 13
			ld  (__y2), a
			ld  a, 72
			ld  (__t), a
	#endasm
	draw_rectangle ();	
	// With CHR_MAPPED_TILES the charset may have no font: give GAME_OVER_TEXT
	// in your own characters (draw_text prints c - 32) or nothing is printed.
	#if !defined CHR_MAPPED_TILES || defined GAME_OVER_TEXT
	draw_text (11, 12, 
		#ifndef CPC
			64+1*8+7, 
		#endif
		GAME_OVER_TEXT);
	#endif
	

	#ifdef CPC
		cpc_UpdateNow (0);
		AY_PLAY_MUSIC (2);
	#else 
		#asm 
				call SPUpdateNow
		#endasm
		peta_el_beeper (5);
	#endif

	no_break ();
	espera_activa (5000);

	#ifdef CPC
		AY_STOP_SOUND ();
	#endif
}
#endif
